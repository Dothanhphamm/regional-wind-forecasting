# 20-year training results

The Tufts production run used Slurm array `7585560` for nine fits and job
`7585561` for the 2022 evaluation. All jobs completed successfully with exit
code 0.

- Training histories: 10-year archived models versus 20-year models trained on 7,302 daily cases from 1998–2017.
- Models: conventional LSTM, plain PredRNN, and PredRNN with mass and dry-static-energy constraints.
- Test: 362 common issue dates in 2022.
- Physics weights: mass `0.030`, dry static energy `0.003`.
- Result tables: `summary.csv`, `per_seed.csv`, `paired_gains.csv`, and `finalists.csv`.

The complete downloaded run is in `results/wind20-IwVaeS/`. It contains all
nine checkpoints, metrics, logs, package information, and Slurm job records.
