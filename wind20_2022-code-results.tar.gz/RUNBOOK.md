# Twenty years of training and the 2022 wind forecast test

Compare the published ten-year models (2008–2017, 3,650 complete daily forecasts) with nine new fits (1998–2017, 7,302 forecasts) over the original regional grid. The conventional LSTM and plain PredRNN use zero physical loss weights. The constrained PredRNN uses mass 0.030 and dry static energy 0.003 for both histories. The model definitions, optimizer, minibatch size, epoch and patience budgets, and seeds 42–44 follow release v1.0.2.

The nine published finalists and their 2019 interval radii are bundled under `baseline10/`. Each new fit selects its best epoch using the mean of 24- and 48-hour 2018 wind RMSE. Its normalization and diagnostic scales use only its 20-year training window. New interval radii use 2019. Both histories forecast the same 362 daily cases in 2022, using their respective training normalization. The production scoring stage opens 2022 after calibration. A separate 32-case smoke run rehearses the pipeline on 2020.

## Submit and monitor on Tufts

Upload `wind20_2022.tar.gz` to your home or project directory, open a cluster shell there, and run:

```bash
tar -xzf wind20_2022.tar.gz
cd wind20_2022
bash submit.sh
```

The command creates a fresh run directory and prints four Slurm job IDs. Setup verifies all packaged files. It reuses the previous Tufts Python environment when present, otherwise it builds the original pinned CPU environment. An existing compatible environment can also be supplied through `WIND_PYTHON`. The training array permits six concurrent tasks, two CPUs and 6 GB per task. Each task can run up to four hours. The cluster schedules all training.

```bash
squeue -u "$USER"
cat runs/wind20-*/jobs.txt
```

Use the printed run directory for results. A terminal, failed run can be retried with `bash submit.sh runs/wind20-XXXXXX` using its actual directory name. Completed compatible training checkpoints are reused. Failed or timed-out fits without a complete checkpoint start again.

## Read the results

- `finalists.csv` records model, seed, history, weights, training case count, best epoch and validation RMSE.
- `per_seed.csv` and `summary.csv` report all four leads, 500 hPa vector wind RMSE, image metrics, diagnostic errors and 90% interval coverage and width. Means are averages of seed-specific metrics.
- `paired_gains.csv` gives each model’s 10-year minus 20-year RMSE, the plain minus constrained RMSE within each history, and the difference between the two physics gains. Positive values favor the 20-year fit, the constrained model, or a larger 20-year physics benefit, respectively.
- The percentile intervals use 1,000 paired circular seven-day block resamples of issue dates with common draws across models and seeds. They are pointwise and conditional on these fitted seeds and this test year. The primary leads are 24 and 48 hours.
- `daily_wind_mse.npz` includes the dates, lead hours and the underlying daily area-weighted squared vector errors. The result files in `smoke/` refer only to the workflow rehearsal.

The two new weather files can be reconstructed with `python prepare_extension.py` in a source-data environment with xarray, dask, Zarr v2 and fsspec HTTP support. The original release supplies the later development weather, model definitions and archived finalists. Longer training histories also provide more optimizer updates per epoch.

Contains modified Copernicus Climate Change Service information for 1998–2022. Neither the European Commission nor ECMWF is responsible for any use made of this information. See the included data and SqueezeNet/Torchvision notices.
