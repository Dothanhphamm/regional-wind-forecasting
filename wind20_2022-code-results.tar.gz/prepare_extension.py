"""Extract the two additional WeatherBench 2 ERA5 periods on the original grid."""
import os
from pathlib import Path

import fsspec
import numpy as np
import xarray as xr

from prepare_data import ARCHIVE, FIELDS

ROOT = Path(__file__).resolve().parent


def check(ds, first, last):
    expected = np.arange(np.datetime64(f"{first}-01-01T00"), np.datetime64(f"{last+1}-01-01T00"),
                         np.timedelta64(6, "h"))
    np.testing.assert_array_equal(ds.time.values, expected)
    np.testing.assert_allclose(ds.latitude.values, np.arange(5)*5.625 + 30.9375)
    np.testing.assert_allclose(ds.longitude.values, np.arange(7)*5.625 + 264.375)
    if not np.isfinite(ds.to_array().values).all() or ds.surface_pressure.min().item() <= 60000:
        raise ValueError("Invalid fields or pressure levels below ground")


def main():
    for first, last, name in [(1998, 2007, "regional_1998_2007.nc"), (2022, 2022, "holdout_2022.nc")]:
        path = ROOT / name
        if path.exists():
            with xr.open_dataset(path, engine="scipy") as ds:
                check(ds, first, last)
            continue
        pieces = []
        with xr.open_zarr(fsspec.get_mapper(ARCHIVE), consolidated=True, chunks={}) as archive:
            for year in range(first, last+1):
                region = archive.sel(time=str(year), latitude=slice(29.375, 55.625),
                                     longitude=slice(264.375, 300.625))
                fields = {f"{prefix}{p}": region[var].sel(level=p, drop=True)
                          for var, (prefix, levels) in FIELDS.items() for p in levels}
                fields["surface_pressure"] = region.surface_pressure
                pieces.append(xr.Dataset(fields).transpose("time", "latitude", "longitude").compute(num_workers=4))
                print(f"Read ERA5 {year}", flush=True)
        ds = xr.concat(pieces, dim="time", join="exact")
        check(ds, first, last)
        ds.attrs = {"source": ARCHIVE, "years": f"{first}-{last}"}
        tmp = path.with_suffix(f".{os.getpid()}.partial.nc")
        ds.to_netcdf(tmp, engine="scipy")
        tmp.replace(path)
        print(f"Wrote {path.name}", flush=True)


if __name__ == "__main__":
    main()
