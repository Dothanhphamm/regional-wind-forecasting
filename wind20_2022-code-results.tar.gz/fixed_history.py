"""Train the fixed 20-year models and compare both histories on identical dates."""
import argparse
import itertools
import json
import math
import os
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from experiment import Diagnostics, LEADS, fit, windows
from followup import ARMS, build, load_trial, predictions, read_maps
from paper_models import WindMapMetrics

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "baseline10"
OLD = ROOT / "regional_2008_2020.nc"
EARLY = ROOT / "regional_1998_2007.nc"
TEST = ROOT / "holdout_2022.nc"
SEEDS = (42, 43, 44)
TRIALS = list(itertools.product(ARMS, SEEDS))
N_FIT = {10: 3650, 20: 7302}


def parameters(arm, seed, years):
    return dict(arm=arm, seed=seed, training_years=years, lr=0.0001,
                mass=0.030 if arm == "both" else 0., energy=0.003 if arm == "both" else 0.)


def atomic_save(obj, path):
    tmp = path.with_suffix(f".{os.getpid()}.part")
    torch.save(obj, tmp)
    tmp.replace(path)


def get_cases(maps, mean, std, smoke):
    x, y = windows((maps - mean) / std)
    return (x[:32], y[:32]) if smoke else (x, y)


def check_saved(saved, arm, seed, years, smoke):
    n = 32 if smoke else N_FIT[years]
    if (saved["params"] != parameters(arm, seed, years) or saved["smoke"] != smoke
            or saved["n_fit"] != n or not np.isfinite(saved["best"])):
        raise ValueError(f"Incompatible checkpoint for {years} years, {arm}, seed {seed}")


def train(run, index, smoke):
    arm, seed = TRIALS[index]
    path = run / f"trial-{index:02d}.pt"
    if path.exists():
        check_saved(load_trial(run, index), arm, seed, 20, smoke)
        return
    earlier, lat, lon = read_maps(EARLY, ("1998", "2007"))
    later, _, _ = read_maps(OLD, ("2008", "2017"))
    maps = torch.cat((earlier, later))
    del earlier, later
    mean = maps.mean((0, 2, 3))[:, None, None]
    std = maps.std((0, 2, 3))[:, None, None]
    x, y = get_cases(maps, mean, std, smoke)
    del maps
    n_fit = len(x)
    assert n_fit == (32 if smoke else N_FIT[20])
    val = get_cases(read_maps(OLD, ("2018", "2018"))[0], mean, std, smoke)
    diag = Diagnostics(mean, std, lat, lon)
    budgets = diag.budgets(x, y)
    scale = budgets.std((0, 1, 3, 4), keepdim=True).clamp_min(1e-12)
    params = parameters(arm, seed, 20)
    curve = []
    torch.manual_seed(seed)
    best, epoch, state = fit(build(arm, x.shape[2:]), x, y, budgets, val, diag, scale,
                             params["lr"], (params["mass"], params["energy"]),
                             2 if smoke else 60, seed, patience=10, history=curve, paper_loss=True)
    saved = dict(params=params, mean=mean, std=std, best=best, epoch=epoch, state=state,
                 n_fit=n_fit, curve=curve, budget_scale=scale, smoke=smoke)
    check_saved(saved, arm, seed, 20, smoke)
    atomic_save(saved, path)
    print(f"Finished {arm} seed {seed}, best epoch {epoch}/{len(curve)}, 2018 RMSE {best:.4f}", flush=True)


def finalists(run, smoke):
    manifest = json.loads((BASE / "frozen.json").read_text())
    if manifest["smoke"] or manifest["training_years"] != 10:
        raise ValueError("Expected the published ten-year finalists")
    models = {}
    for i, (arm, seed) in enumerate(TRIALS):
        baseline_id = manifest["trial_indices"][arm][SEEDS.index(seed)]
        for years, cp in [(10, load_trial(BASE, baseline_id)), (20, load_trial(run, i))]:
            check_saved(cp, arm, seed, years, smoke and years == 20)
            models[years, arm, seed] = cp
    return manifest, models


def calibrate(run, smoke):
    manifest, models = finalists(run, smoke)
    old = torch.load(BASE / "intervals.pt", map_location="cpu", weights_only=True)
    if old["calibration_year"] != 2019 or old["trial_indices"] != manifest["trial_indices"]:
        raise ValueError("Baseline interval provenance mismatch")
    maps, _, _ = read_maps(OLD, ("2019", "2019"))
    radii, rows = {}, []
    for (years, arm, seed), cp in models.items():
        rows.append(dict(**cp["params"], n_fit=cp["n_fit"], best_epoch=cp["epoch"],
                         epochs_run=len(cp["curve"]), validation_rmse_ms=cp["best"]))
        if years == 10:
            trial = manifest["trial_indices"][arm][SEEDS.index(seed)]
            radius = old["radii"][f"{arm}/{trial}"]
        else:
            x, y = get_cases(maps, cp["mean"], cp["std"], smoke)
            pred = predictions(cp, x)
            err = ((pred-y)*cp["std"])[:, :, :2, 1:-1, 1:-1]
            rank = min(len(y), math.ceil(.90*(len(y)+1)))
            radius = err.abs().kthvalue(rank, dim=0).values
        radii[f"{years}/{arm}/{seed}"] = radius
    pd.DataFrame(rows).to_csv(run / "finalists.csv", index=False)
    atomic_save(dict(year=2019, radii=radii, smoke=smoke), run / "intervals.pt")


def paired_gains(error, run):
    n = next(iter(error.values())).shape[0]
    rng = np.random.default_rng(2022)
    starts = rng.integers(n, size=(1000, math.ceil(n/7)))
    ids = ((starts[:, :, None] + np.arange(7)) % n).reshape(1000, -1)[:, :n]
    point, boot = {}, {}
    for years, arm in itertools.product((10, 20), ARMS):
        values = [error[years, arm, seed] for seed in SEEDS]
        point[years, arm] = np.mean([np.sqrt(v.mean(0)) for v in values], axis=0)
        boot[years, arm] = np.mean([np.sqrt(v[ids].mean(1)) for v in values], axis=0)
    comparisons = [(f"10y_minus_20y_{arm}", [(10, arm, 1), (20, arm, -1)]) for arm in ARMS]
    for years in (10, 20):
        comparisons.append((f"physics_gain_{years}y", [(years, "plain", 1), (years, "both", -1)]))
    comparisons.append(("physics_gain_20y_minus_10y", [(20, "plain", 1), (20, "both", -1),
                                                      (10, "plain", -1), (10, "both", 1)]))
    rows = []
    for contrast, terms in comparisons:
        gain = sum(sign*point[years, arm] for years, arm, sign in terms)
        samples = sum(sign*boot[years, arm] for years, arm, sign in terms)
        lo, hi = np.quantile(samples, [.025, .975], axis=0)
        for j, lead in enumerate(LEADS):
            rows.append(dict(contrast=contrast, lead_h=lead, gain_ms=gain[j], lower95=lo[j], upper95=hi[j]))
    pd.DataFrame(rows).to_csv(run / "paired_gains.csv", index=False)


def score(run, smoke):
    manifest, models = finalists(run, smoke)
    intervals = torch.load(run / "intervals.pt", map_location="cpu", weights_only=True)
    if intervals["year"] != 2019 or intervals["smoke"] != smoke:
        raise ValueError("Expected matching 2019 calibration")
    year = 2020 if smoke else 2022
    maps, lat, lon = read_maps(OLD if smoke else TEST, (str(year), str(year)))
    images = WindMapMetrics(manifest["image_speed_max_ms"])
    rows, errors = [], {}
    for (years, arm, seed), cp in models.items():
        x, y = get_cases(maps, cp["mean"], cp["std"], smoke)
        assert len(x) == (32 if smoke else 362)
        diag = Diagnostics(cp["mean"], cp["std"], lat, lon)
        pred = predictions(cp, x)
        err = ((pred-y)*cp["std"])[:, :, :2, 1:-1, 1:-1]
        radius = intervals["radii"][f"{years}/{arm}/{seed}"]
        coverage = ((err.abs() <= radius)*diag.weight).mean((0, 3, 4))
        widths = (2*radius*diag.weight).mean((2, 3))
        daily = diag.wind_mse(y, pred)
        budget = ((diag.budgets(x, pred)-diag.budgets(x, y)).square()*diag.weight).mean((0, 3, 4)).sqrt()
        ssim, lpips = images.score(pred, y, cp["mean"], cp["std"])
        errors[years, arm, seed] = daily.numpy().astype(np.float64)
        rmse = daily.mean(0).sqrt()
        for j, lead in enumerate(LEADS):
            rows.append(dict(training_years=years, arm=arm, seed=seed, test_year=year, n_days=len(y),
                             lead_h=lead, wind_rmse_ms=rmse[j].item(), SSIM=ssim[j].item(), LPIPS=lpips[j].item(),
                             mass_residual_rmse_per_s=budget[j,0].item(), dse_tendency_rmse_W_kg=budget[j,1].item(),
                             u_coverage=coverage[j,0].item(), v_coverage=coverage[j,1].item(),
                             u_width_ms=widths[j,0].item(), v_width_ms=widths[j,1].item()))
    frame = pd.DataFrame(rows)
    if not np.isfinite(frame.select_dtypes("number")).all().all():
        raise ValueError("Non-finite evaluation")
    frame.to_csv(run / "per_seed.csv", index=False)
    frame.drop(columns="seed").groupby(["training_years","arm","test_year","n_days","lead_h"]).mean().to_csv(run / "summary.csv")
    dates = np.datetime64(f"{year}-01-02") + np.arange(len(x))
    np.savez_compressed(run / "daily_wind_mse.npz", issue_dates=dates, lead_h=LEADS,
                        **{f"{h}_{a}_{s}": e for (h,a,s), e in errors.items()})
    paired_gains(errors, run)
    print(f"Compared all 18 fits on {len(x)} common issue dates in {year}", flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("stage", choices=("smoke", "train", "finish"))
    p.add_argument("run", type=Path)
    p.add_argument("--index", type=int, choices=range(len(TRIALS)), default=0)
    args = p.parse_args()
    torch.set_num_threads(int(os.environ.get("SLURM_CPUS_PER_TASK", "2")))
    args.run.mkdir(parents=True, exist_ok=True)
    if args.stage == "train":
        train(args.run, args.index, False)
    else:
        smoke = args.stage == "smoke"
        if smoke:
            for i in range(len(TRIALS)):
                train(args.run, i, True)
        calibrate(args.run, smoke)
        score(args.run, smoke)


if __name__ == "__main__":
    main()
